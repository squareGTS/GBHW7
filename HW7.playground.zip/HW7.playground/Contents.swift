import UIKit

enum errors: Error{
    case wrongButtonPressed
    case didNotPressed(error: String)
    case numberOfClicks
}


class Mouse {
    
    var errorType = "Error 4563 mouse is not conected"
    
    func pressButton(leftButton: Bool, rightButton: Bool, amountOfClicks: Int) throws {
        
        guard leftButton == true else {
            throw errors.wrongButtonPressed
        }
        
        guard rightButton == true else {
            throw errors.didNotPressed(error: errorType)
        }
        
        guard amountOfClicks >= 2 else {
            throw errors.numberOfClicks
        }
        print("Another type of errors")
    }
    
}

let mouse = Mouse()

do {
    try mouse.pressButton(leftButton: false, rightButton: true, amountOfClicks: 1)
} catch errors.numberOfClicks {
    print("Less than requared")
} catch errors.didNotPressed(error: "Why?") {
    print("Buttons did not pressed")
} catch errors.wrongButtonPressed {
    print("You pressed not right button")
}



enum letters: String, Error {
    case a
    case b
    case c
    case d
    case e
    case f
    case g
}


enum player: String, Error {
    case play
    case next
    case previous
    case stop
}


class KeyBoard {
    
    func pressButton(pressedButton: String, amountOfClicks: Int) throws {
        guard letters.a.rawValue != "a" else {
            throw letters.a
        }
        guard letters.b.rawValue != "b" else {
            throw letters.b
        }
        guard letters.c.rawValue != "c" else {
            throw letters.c
        }
        guard letters.d.rawValue != "d" else {
            throw letters.d
        }
        guard letters.e.rawValue != "e" else {
            throw letters.e
        }
        guard letters.f.rawValue != "f" else {
            throw letters.f
        }
        guard letters.g.rawValue != "g" else {
            throw letters.g
        }
    }
    func pressTouchBarButton(pressedButton: String) throws {
        guard  player.play.rawValue != pressedButton else {
            throw player.play
        }
        guard  player.next.rawValue != pressedButton else {
            throw player.next
        }
        guard  player.previous.rawValue != pressedButton else {
            throw player.previous
        }
        guard  player.stop.rawValue != pressedButton else {
            throw player.stop
        }
    }
}

let keyBoard = KeyBoard()

do {
    try keyBoard.pressButton(pressedButton: "a", amountOfClicks: 1)
} catch letters.a {
    print("letter a")
} catch letters.b {
    print("latter b")
} catch letters.c {
    print("latter c")
} catch letters.d {
    print("latter d")
} catch letters.e {
    print("latter e")
} catch letters.f {
    print("latter f")
} catch letters.g {
    print("latter g")
}

do {
    try keyBoard.pressTouchBarButton(pressedButton: "play")
} catch player.play {
    print("play")
} catch player.next {
    print("next")
} catch player.previous {
    print("previous")
} catch player.stop {
    print("stop")
}
